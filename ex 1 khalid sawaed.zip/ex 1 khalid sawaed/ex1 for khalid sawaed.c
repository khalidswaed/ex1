/******************
Name: Khalid Sawaed
ID: 326332525
Assignment: ex1
*******************/
#include <stdio.h>

// REMIDER : YOU CANT USE ANY CONTROL FLOW OPERATIONS OR FUNCTIONS, ONLY BITWISE.

int main() {
  
  // What bit
  printf("What bit:\n");
  /*Scan two integers (representing number and a position)
  Print the bit in this position. */
  int number,position,bit ;
     printf("Enter a number:");
    scanf("%d",&number);
    printf("Enter position");
         scanf("%d",&position);
         bit = (number >> position) & 1;
printf("The bit in position %d is: %d\n", position, bit);

  // Set bit
  printf("\nSet bit:\n");
  /*Scan two integers (representing number and a position)
  Make sure the bit in this position is "on" (equal to 1)
  Print the output
  Now make sure it's "off" (equal to 0)
  Print the output */
          printf("Enter a number:");
           scanf("%d",&number);
           printf("Enter position:");
           scanf("%d",&position);
           number = number | (1 << position);
 printf("Number with bit at position %d turned ON: %d\n", position, number);
 number = number & ~(1 << position);
 printf("Number with bit at position %d turned OFF: %d\n", position, number);

  // Toggle bit
  printf("\nToggle bit:\n");
  /*Scan two integers (representing number and a position)
  Toggle the bit in this position
  Print the new number */
    printf("Enter a number: ");
    scanf("%d", &number);

    printf("Enter a position: ");
    scanf("%d", &position);
    number = number ^ (1 << position);
    printf("New number after toggling the bit at position %d: %d\n", position, number);
  
  // Even - Odd
  printf("\nEven - Odd:\n");
  /* Scan an integer
  If the number is even - print 1, else - print 0. */
  printf("Enter a number: ");
  scanf("%d", &number);
  if(number%2 == 0)
      printf("1\n");
         else printf("0\n");
  // 3, 5, 7, 11
  printf("\n3, 5, 7, 11:\n");
  /* Scan two integers in octal base
  sum them up and print the result in hexadecimal base
  Print only 4 bits, in positions: 3,5,7,11 in the result. */
    int octal1, octal2, sum;


    printf("Enter the first number: ");
    scanf("%o", &octal1);

    printf("Enter the second number: ");
    scanf("%o", &octal2);

    sum = octal1 + octal2;

    printf("Sum in hexadecimal base: %X\n", sum);

    printf("\nBits at positions 3, 5, 7, and 11:\n");

    int bit3 = (sum >> 3) & 1;
    int bit5 = (sum >> 5) & 1;
    int bit7 = (sum >> 7) & 1;
    int bit11 = (sum >> 11) & 1;

    printf("Bit 3: %d\n", bit3);
    printf("Bit 5: %d\n", bit5);
    printf("Bit 7: %d\n", bit7);
    printf("Bit 11: %d\n", bit11);

  printf("Bye!\n");
  
  return 0;
}
